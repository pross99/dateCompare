package calculater;

import java.time.LocalDate;
import java.time.Period;

public class Date {


     public int findDifference(LocalDate startDate, LocalDate endDate) {return startDate.compareTo(endDate); }
     {


    }



    }

